"""
Shared Prompts & Re-exports for Variable Level Specs Generation (Single-Call Pattern)

This module contains:
- ENHANCED_OUTPUT_FORMAT: shared JSON output schema
- USER_PROMPT_TEMPLATE: common user-message template with study_context/global_method_ref

Domain-specific prompts live in dedicated files:
- adsl_prompts.py   — ADSL single-call system prompt (loaded from .md)
- bds_prompts.py    — BDS  single-call system prompt (loaded from .md)
- occds_prompts.py  — OCCDS single-call system prompt (loaded from .md)
- adtte_prompts.py  — ADTTE single-call system prompt (loaded from .md)

For backward compatibility, domain-specific constants are re-exported here so
existing ``from ..prompts.spec_generation_prompts import X`` imports continue to work.
"""

# =============================================================================
# ENHANCED OUTPUT FORMAT (V2)
# =============================================================================

AMOUNT_UNIT_MISSINGNESS_GUIDELINES = """
## Amount and Unit Consistency

When a unit describes an amount on the same record, set the unit to missing
whenever that amount is missing. If the amount's entire mapping is set to
missing, set its unit's entire mapping to missing too. A fixed unit such as
`mg` may be used only when the corresponding amount is present; express this
condition in the derivation rule and developer notes, not as an unconditional
`assigned_value`. Apply this to all supported amount/unit pairs (for example,
`EXDOSE`/`EXDOSU` in ADEX). Preserve a unit independently only when the input
documents explicitly require it.
"""

ENHANCED_OUTPUT_FORMAT = """
## Output Format
Return a JSON **array** of variable objects with this EXACT structure:

```json
[
  {
    "name": "STUDYID",
    "label": "Study Identifier",
    "type": "Char",
    "length": 12,
    "format": null,
    "core": "Req",
    "origin": "SDTM",
    "sourceVariable": "DM.STUDYID",
    "derivationRule": "Direct copy from DM.STUDYID",
    "derivation_method": "",
    "source_variables": ["DM.STUDYID"],
    "study_context_refs": [],
    "isRequired": false,
    "codelist": null,
    "comment": "",
    "conformanceRules": ["2", "13", "14"],
    "role": "Identifier",
    "predecessor": "DM.STUDYID",
    "mandatory": "Yes",
    "assigned_value": "",
    "significant_digits": null,
    "cdisc_notes": "STUDYID must be consistent across all domains per ADaM IG 2.1",
    "genai_confidence_score": 0.95,
    "genai_rationale": "STUDYID is a required identifier variable per ADaM IG, directly copied from DM domain"
  }
]
```

### Variable Field Definitions:
- **name**: Variable name (uppercase, max 8 chars, must start with letter)
- **label**: Variable label (max 40 chars)
- **type**: "Char" or "Num" only
- **length**: Character length for Char, 8 for Num
- **format**: Display format (null if none, e.g., "DATE9." for date vars)
- **core**: "Req" (required), "Cond" (conditional), or "Perm" (permissible)
- **origin**: "SDTM" (copied from SDTM), "Derived" (computed), or "ADSL" (merged from ADSL)
- **sourceVariable**: Source domain.variable or derivation inputs (e.g., "DM.STUDYID")
- **derivationRule**: Clear derivation logic or "Direct copy from <source>"
- **derivation_method**: GM.* method ID from Global Method Reference (empty if not applicable)
- **source_variables**: List of source variables used (e.g., ["DM.STUDYID", "EX.EXSTDTC"])
- **study_context_refs**: List of study_context fields used (e.g., ["population_definitions.SAFETY"])
- **isRequired**: false (set by downstream validation)
- **codelist**: Codelist name if applicable (e.g., "NY", "SEX", "RACE", "NRIND")
- **comment**: Additional notes (usually empty)
- **conformanceRules**: List of applicable ADaM conformance rule IDs as strings
- **role**: CDISC variable role - one of: "Identifier", "Topic", "Timing", "Record Qualifier", "Grouping Qualifier", "Result Qualifier", "Rule"
- **predecessor**: Predecessor variable from source (e.g., "DM.AGE" for AGE). Empty string if no direct predecessor.
- **mandatory**: "Yes" if variable is required per ADaM IG for this domain class, "No" otherwise. Align with Core value.
- **assigned_value**: Fixed assigned value for the variable (e.g., domain name for DOMAIN variable, "DAYS" for AVALU when unit is fixed). Empty string if not applicable.
- **significant_digits**: Number of significant digits for Num variables where precision matters (e.g., 1 for PCHG). null if not applicable.
- **cdisc_notes**: Relevant ADaM IG or CDISC guidance notes for this variable. Brief (1-2 sentences). Empty string if none.
- **genai_confidence_score**: Confidence score between 0.85 and 0.98 reflecting derivation certainty. Higher for direct copies (0.95-0.98), lower for complex derivations (0.85-0.90).
- **genai_rationale**: Brief rationale explaining why this variable is needed, what SAP/regulatory requirement it satisfies, and the derivation approach chosen. Must not be empty.

**IMPORTANT**: Return ONLY the JSON array. Do not wrap it in an object. Do not include markdown code fences.
""" + AMOUNT_UNIT_MISSINGNESS_GUIDELINES

# =============================================================================
# SOURCE FIDELITY GUIDELINES (shared across all ADaM agent prompts)
# =============================================================================

SOURCE_FIDELITY_GUIDELINES = """
## Source Fidelity Guidelines (Mandatory)

You MUST adhere to the following grounding rules at all times:

1. **Document-Only Answers**: Base your answers ONLY on the uploaded/provided documents. Nothing else.
2. **Not Found Protocol**: If information isn't found in the provided documents, say 'Not Found'. Don't guess.
3. **Citation Required**: For each claim, cite [Document, Page/Section, Quote] to support it.
4. **Uncertainty Marking**: If uncertain about any information, mark it as [Unverified].
5. **High-Confidence Only**: Only respond with information you are 100% confident is from the provided files.
6. **Quote Verification**: For each claim, provide the exact quote from the source document that supports it. If you can't find a supporting quote, retract the claim.
7. **Cross-Verification**: Review your analysis against the provided document(s). Flag any claims that aren't directly supported.
8. **Unsupported Claims Check**: Identify and explicitly flag any claims that are NOT supported by the source documents.
"""

# =============================================================================
# USER PROMPT TEMPLATE (V2 — with study_context and global_method_ref)
# =============================================================================

USER_PROMPT_TEMPLATE = """Generate variable-level specifications for the following ADaM domain:

## Target Domain
**Domain:** {target_domain}
**Domain Class:** {domain_class}

## SAP Analysis Content
{sap_analysis}

## SDTM Correlation Information
{correlation_output}

## Predecessor Domain Specifications
{predecessor_specs}

{study_context_fragment}

{global_method_ref_fragment}

---

Based on the above information, generate comprehensive variable-level specifications for {target_domain}.

Remember to:
1. Include all standard {domain_class} identifier variables (STUDYID, USUBJID)
2. Include domain-specific key variables based on domain class
3. For non-ADSL domains, include variables merged from ADSL with origin = "ADSL"
4. Provide clear derivation rules for each variable
5. Follow CDISC ADaM naming conventions (max 8 characters, uppercase)
6. Include appropriate codelists (NY, SEX, RACE, etc.)
7. Reference GM.* method IDs in derivation_method where applicable
8. Use study_context parameters instead of hardcoded study values
9. Include source_variables list for traceability

Return the specifications as a JSON array of variable objects.
"""

# =============================================================================
# RE-EXPORTS — backward compatibility for existing imports
# =============================================================================

# ADSL
from .adsl_prompts import ADSL_SYSTEM_PROMPT  # noqa: E402, F401

# BDS
from .bds_prompts import BDS_SYSTEM_PROMPT  # noqa: E402, F401

# OCCDS
from .occds_prompts import (  # noqa: E402, F401
    OCCDS_SYSTEM_PROMPT,
    OCCDS_ADAE_SYSTEM_PROMPT,
    OCCDS_ADCM_SYSTEM_PROMPT,
)

# ADTTE
from .adtte_prompts import ADTTE_SYSTEM_PROMPT  # noqa: E402, F401
